#!/bin/bash

# Install dependencies
npm install

# Start the application
npm start
